<?php
header("Access-Control-Allow-Origin: *");

//To display errors, uncomment what is below:
// ini_set('error_reporting', E_ALL);
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);

include __DIR__ .'/settings.php';

$wallet_money= 3;
if(isset($wallet_egold_number))$wallet_egold_number= preg_replace("/[^0-9]/",'',$wallet_egold_number);
else $wallet_egold_number= '';
if(strlen($wallet_egold_number)!=18){echo '{"error": "wallet_egold_number"}';exit;}

if(isset($wallet_egold_key))$wallet_egold_key= preg_replace("/[^0-9a-z]/",'',$wallet_egold_key);
else $wallet_egold_key= '';
if(!(strlen($wallet_egold_key)>2000 && strlen($wallet_egold_key)<2100)){echo '{"error": "wallet_egold_key"}';exit;}
else {
	include __DIR__ .'/egold_crypto/falcon.php';
	try {$falcon_p= Falcon\createPublicKey($wallet_egold_key);}
	catch (Exception $e){$falcon_p='';}
}
if(!isset($falcon_p) || !$falcon_p){echo '{"error": "wallet_egold_key"}';exit;}
if(isset($wallet_egold_referer_number))$wallet_egold_referer_number= preg_replace("/[^0-9]/",'',$wallet_egold_referer_number);
else $wallet_egold_referer_number= 0;
if(isset($wallet_egold_referer) && $wallet_egold_referer== 1 && isset($_REQUEST['pin']) && ($_REQUEST['pin']==1 || strlen(preg_replace("/[^0-9]/",'',$_REQUEST['pin']))==18))$_REQUEST['pin']= preg_replace("/[^0-9]/",'',$_REQUEST['pin']);
else if($wallet_egold_referer_number==1 || strlen($wallet_egold_referer_number)==18)$_REQUEST['pin']= $wallet_egold_referer_number;
if(!isset($_REQUEST['pin']))$_REQUEST['pin']=0;
if(!isset($noda) || !is_array($noda) || !isset($noda[0]) || !$noda[0]){echo '{"error": "noda"}';exit;} 
else $noda= $noda[mt_rand(0,(count($noda)-1))];
$noda= preg_replace("/[^0-9a-z.]/",'',$noda);
if(!filter_var($noda, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)){echo '{"error": "noda"}';exit;}
if(!isset($wallet_money) || !((int)$wallet_money>3))$wallet_money= 3;
function curl_check_toArr($url,$params){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
	if($params){
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
	}
	curl_setopt($ch, CURLOPT_TIMEOUT_MS, 20*1000);
	$json = curl_exec ($ch);
	curl_close ($ch);
	return json_decode($json);
}
$json_height= curl_check_toArr('http://'.$noda.'/egold.php?type=height&wallet='.$wallet_egold_number,'');
if(isset($json_height->height) && $json_height->height>=0){
	$wallet_height= (int)$json_height->height+1;
} else {echo '{"error": "noda: '.$noda.'"}';exit;}
if($_REQUEST['pin']>1){
	$json_height= curl_check_toArr('http://'.$noda.'/egold.php?type=height&wallet='.$_REQUEST['pin'],'');
	if(!isset($json_height->height) || !($json_height->height>=0))$_REQUEST['pin']=0;
}
$chars="qazxswedcvfrtgbnhyujmkiop1234567890QAZXSWEDCVFRTGBNHYUJMKOLP";
$max=68000;
$size=mb_strlen($chars)-1;
$newpassword=null;
$hashpassword=null;
while($max--)$newpassword.=$chars[rand(0,$size)];
try {list($falcon_k_reg,$falcon_p_reg)= Falcon\createKeyPair(128, uniqid().uniqid().uniqid().uniqid().uniqid().$newpassword);}
catch (Exception $e){exit;}
function bchexdec($hex){
	$dec = 0; $len = strlen($hex);
	for ($i = 1; $i <= $len; $i++)$dec = bcadd($dec, bcmul(strval(hexdec($hex[$i - 1])), bcpow('16', strval($len - $i))));
	return $dec;
}
function sha_dec($str){return substr(bchexdec(gen_sha3($str,19)),0,19);}
$str_s_reg='30'.sha_dec($falcon_p_reg);
try {$falcon_s_reg= Falcon\sign($falcon_k_reg, $str_s_reg);}
catch (Exception $e){exit;}
$str_s= $GLOBALS['wallet_egold_number'].'00'.$wallet_money.$_REQUEST['pin'].$wallet_height.$noda.$falcon_p_reg.$falcon_s_reg;
try {$falcon_s= Falcon\sign($GLOBALS['wallet_egold_key'], $str_s);}
catch (Exception $e){exit;}
$params = array(
	'type' => 'send',
	'wallet' => $GLOBALS['wallet_egold_number'],
	'recipient' => '00',
	'money' => $wallet_money,
	'pin' => $_REQUEST['pin'],
	'height' => $wallet_height,
	'signpubreg' => $falcon_p_reg,
	'signreg' => $falcon_s_reg,
	'signpub' => $falcon_p,
	'sign' => $falcon_s
);
$json_send= curl_check_toArr('http://'.$noda.'/egold.php',$params);
if(isset($json_send->walletnew) && strlen($json_send->walletnew)==23){
	function gold_wallet_view($wallet){return 'G-'.substr($wallet,0,4).'-'.substr($wallet,4,5).'-'.substr($wallet,9,4).'-'.substr($wallet,13,5);}
	$message= "New wallet number: <b>".$json_send->walletnew."</b><br/><br/>Private Key: <b>".$falcon_k_reg."</b><br/><br/>The IP address node of the people who created the wallet and can be connected to it when entering the wallet: <b>".$noda."</b><br/><br/>".($_REQUEST['pin']==1?"This wallet does not have referers, since it was created using a service address <b>G-1</b>":"Wallet of the <b>level 1 referer</b> who created the current wallet: <b>".gold_wallet_view(($_REQUEST['pin']>1?$_REQUEST['pin']:$GLOBALS['wallet_egold_number']))."</b>")."<br/><br/><b><i>* The new wallet will be available in 3 minutes.</i></b><br/><br/><b>1.</b> It is necessary to replenish the wallet up to 3 coins, change the private key and only then accept transactions on the wallet and use it for other purposes.<br/><b>2.</b> Until the private key is changed, the wallet is considered unsafe.<br/><b>3.</b> In any case, only a new wallet is registered here, and all responsibility for its use lies with you.<br/>";
	echo '{"wallet": "'.$message.'"}';
	exit;
} else {echo '{"error": "wallet_new"}';exit;}
?>