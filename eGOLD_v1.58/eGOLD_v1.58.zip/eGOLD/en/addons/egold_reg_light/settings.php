<?php //version 1.2
//All files of this supplement for automatic wallet registration must be located in the folder /egold_reg_light/ from the site root.
//If the addon does not work, you need to check or ask the support yourself if PHP: PHP versions from 7.1 and its modules are installed: bcmath, gmp, curl
//You can check the operation of the addon by running index.html file opening its URL in the address bar of the browser: http://[site]/egold_ reg_light/index.html
//To embed an automatic wallet registration form under your wallet in the site page, you need to tag the code from index.html so that it is:
//1. <head><script src="/egold_reg/js/jquery-3.2.1.min.js"></script><style>[style code]</style></head>
//2. <body>[html form and button code]</body>
//3. <script>[script code]</script>
//Or simply copy the content between the specified start and end comments to the location where the registration button and the registration message itself will be displayed

$wallet_egold_number= "";//The wallet number from which registration will be made. Example: 111122222333344444 or G-1111-22222-3333-44444
$wallet_egold_key= "";//The key to the wallet specified in the $ wallet _ egold _ number parameter. Example: 0707000f00f7fff9ff00000b001100ffff0a000 (about 2050 symbols)

$wallet_egold_referer= 1;//If =1 and the user followed a referral link of http://[IP or the website]/[the page of location HTML of the code from the index.html file]/?ref=G-1000-00000-0000-00000 (where G-1000-00000-0000-00000 is any purse), the created purse becomes a referral of the purse specified in the reference if such purse exists. =0 turns off acceptance of referral links. When you specify a service address G-1 in a referral link instead of a wallet, the wallet created will not be someone else's referral.
$wallet_egold_referer_number= "";//The wallet number whose referral will be the created wallet if there is no reference link at $ wallet _ egold _ referer = 1. Example: 111122222333344444 or G-1111-22222-3333-44444. When you specify a service address G-1 instead of a wallet, the created wallet will not be anyone's referral.

//You need to write 1 or more trusted jobs (you can add similarly line-by-line: $noda[]= "ip_node_address";)
$noda[]= "";
//Example:
// $noda[]= "178.21.8.100";
// $noda[]= "178.21.8.101";
// $noda[]= "178.21.8.102";
?>